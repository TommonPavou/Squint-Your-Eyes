package github.tommonpavou.client;

import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class SquintConfig {
    // Inizializza il file di config nella directory di configurazione dell'istanza di Fabric
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "squint-your-eyes.properties");
    private static final Logger LOGGER = LoggerFactory.getLogger(SquintYourEyesClient.MOD_ID);

    // Valori predefiniti
    public static float minZoom = 1.1f;
    public static float maxZoom = 3.0f;
    public static float intensityMultiplier = 1.15f;
    public static float zoomStep = 0.15f;
    public static boolean rememberLastZoom = true;
    // Impostazione per determinare se il crosshair debba dissolversi durante lo zoom (default true)
    public static boolean fadeCrosshair = true;

    // Carica il file di configurazione e imposta i valori
    public static void loadConfig() {
        Properties properties = new Properties();

        if (!CONFIG_FILE.exists()) {
            createConfig(); // Crea il file con i valori di default se non esiste
            return;
        }

        try (FileInputStream fileInputStream = new FileInputStream(CONFIG_FILE)) {
            properties.load(fileInputStream);
            minZoom = setValue(properties.getProperty("min_zoom"), 1.1f);
            maxZoom = setValue(properties.getProperty("max_zoom"), 3.0f);
            intensityMultiplier = setValue(properties.getProperty("intensity_multiplier"), 1.15f);
            zoomStep = setValue(properties.getProperty("zoom_step"), 0.15f);
            rememberLastZoom = setBooleanValue(properties.getProperty("remember_last_zoom"), true);
            // Carica la proprietà dal file di configurazione o usa il default true
            fadeCrosshair = setBooleanValue(properties.getProperty("fade_crosshair"), true);
        } catch (IOException e) {
            LOGGER.error("Failed to load Squint Your Eyes configuration file", e);
        }
    }

    // Crea il file di configurazione con i valori di default
    public static void createConfig() {
        try {
            // Ottieni la directory del file di configurazione
            File fileDirectory = CONFIG_FILE.getParentFile();
            if (fileDirectory != null && !fileDirectory.exists()) {
                fileDirectory.mkdirs(); // Crea la directory se non esiste
            }

            try (java.io.BufferedWriter writer = new java.io.BufferedWriter(new java.io.OutputStreamWriter(new FileOutputStream(CONFIG_FILE), java.nio.charset.StandardCharsets.UTF_8))) {
                writer.write("# Squint Your Eyes Configuration File\n");
                writer.write("# Note: Altering min_zoom, max_zoom, and zoom_step might negatively impact zoom fluidity!\n");
                writer.write("# min_zoom: Minimum zoom level\n");
                writer.write("# max_zoom: Maximum zoom level\n");
                writer.write("# intensity_multiplier: Vignette overlay intensity\n");
                writer.write("# zoom_step: Scroll sensitivity\n");
                writer.write("# remember_last_zoom: Whether to remember the last active zoom level (true/false)\n");
                writer.write("# fade_crosshair: Whether to fade out the crosshair when zooming (true/false)\n");
                writer.write("\n");
                writer.write("min_zoom=" + minZoom + "\n");
                writer.write("max_zoom=" + maxZoom + "\n");
                writer.write("intensity_multiplier=" + intensityMultiplier + "\n");
                writer.write("zoom_step=" + zoomStep + "\n");
                writer.write("remember_last_zoom=" + rememberLastZoom + "\n");
                writer.write("fade_crosshair=" + fadeCrosshair + "\n");
            }
        } catch (IOException e) {
            LOGGER.error("Failed to save Squint Your Eyes configuration file", e);
        }
    }

    // Imposta il valore dal file config o carica quello di default se non è presente o non è valido
    private static float setValue(String value, float defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        try {
            return Float.parseFloat(value.trim()); // ParseFloat -> Stringa in valore float
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }

    // Imposta il valore booleano dal file config o carica quello di default se non è presente o non è valido
    private static boolean setBooleanValue(String value, boolean defaultValue) {
        if (value == null) {
            return defaultValue;
        }
        return Boolean.parseBoolean(value.trim());
    }
}