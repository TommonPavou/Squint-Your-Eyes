package github.tommonpavou.client.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import github.tommonpavou.client.SquintYourEyesClient;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void onGetFov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        // Sfrutta tickDelta per rendere l'animazione fluida e indipendente dal frame rate
        // tickDelta è un valore compreso tra 0 e 1 che rappresenta la frazione del tick corrente
        float zoomProgress = SquintYourEyesClient.prevZoomProgress +
                (SquintYourEyesClient.zoomProgress - SquintYourEyesClient.prevZoomProgress) * tickDelta;

        float currentZoom = SquintYourEyesClient.prevZoomLevel +
                (SquintYourEyesClient.zoomLevel - SquintYourEyesClient.prevZoomLevel) * tickDelta;

        /// Se lo zoom è attivo, calcola il FOV finale riducendo quello base di Minecraft
        if (zoomProgress > 0.001f) {
            double baseFov = cir.getReturnValue();
            double targetFov = baseFov / currentZoom;
            // Transiziona il FOV attuale verso il FOV di target e lo applica al gioco
            double modifiedFov = baseFov + (targetFov - baseFov) * zoomProgress;
            cir.setReturnValue(modifiedFov);
        }
    }
}