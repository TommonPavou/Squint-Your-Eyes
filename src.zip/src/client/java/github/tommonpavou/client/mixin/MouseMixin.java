package github.tommonpavou.client.mixin;

import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import github.tommonpavou.client.SquintYourEyesClient;

@Mixin(Mouse.class)
public class MouseMixin {

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        // Gestione dell'input dello scroll per variare lo zoom in modo reattivo
        if (SquintYourEyesClient.tryAdjustZoom(vertical)) {
            ci.cancel();
        }
    }
}