package github.tommonpavou.client.mixin;

import github.tommonpavou.client.SquintConfig;
import github.tommonpavou.client.SquintYourEyesClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class CrosshairRendererMixin {

    @Inject(method = "renderCrosshair", at = @At("HEAD"))
    private void onRenderCrosshair(DrawContext context, CallbackInfo ci) {
        // Calcola il progresso dello zoom attuale basato sul client
        float zoomProgress = SquintYourEyesClient.prevZoomProgress +
                (SquintYourEyesClient.zoomProgress - SquintYourEyesClient.prevZoomProgress) * MinecraftClient.getInstance().getTickDelta();

        // Se l'opzione è attiva e lo zoom è in corso, applica una scala di riduzione al crosshair
        if (SquintConfig.fadeCrosshair && (zoomProgress > 0.001f || SquintYourEyesClient.isSquinting)) {
            float scale = MathHelper.clamp(1.0f - zoomProgress, 0.0f, 1.0f);
            int width = MinecraftClient.getInstance().getWindow().getScaledWidth();
            int height = MinecraftClient.getInstance().getWindow().getScaledHeight();

            context.getMatrices().push();
            // Riduce la scala del crosshair facendolo convergere verso il centro dello schermo
            context.getMatrices().translate(width / 2.0f, height / 2.0f, 0.0f);
            context.getMatrices().scale(scale, scale, 1.0f);
            context.getMatrices().translate(-width / 2.0f, -height / 2.0f, 0.0f);
        }
    }

    @Inject(method = "renderCrosshair", at = @At("RETURN"))
    private void onRenderCrosshairReturn(DrawContext context, CallbackInfo ci) {
        float zoomProgress = SquintYourEyesClient.prevZoomProgress +
                (SquintYourEyesClient.zoomProgress - SquintYourEyesClient.prevZoomProgress) * MinecraftClient.getInstance().getTickDelta();

        // Ripristina la matrice grafica se il crosshair è stato modificato
        if (SquintConfig.fadeCrosshair && (zoomProgress > 0.001f || SquintYourEyesClient.isSquinting)) {
            context.getMatrices().pop();
        }
    }
}