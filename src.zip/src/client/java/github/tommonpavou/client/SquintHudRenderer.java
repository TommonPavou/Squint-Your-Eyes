package github.tommonpavou.client;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

public class SquintHudRenderer {
    public static void register() {
        HudRenderCallback.EVENT.register(SquintHudRenderer::render);
    }

    private static void render(DrawContext context, float tickDelta) {
        float zoomProgress = SquintYourEyesClient.prevZoomProgress +
                (SquintYourEyesClient.zoomProgress - SquintYourEyesClient.prevZoomProgress) * tickDelta;

        MinecraftClient client = MinecraftClient.getInstance();

        if (zoomProgress <= 0.001f) {
            return;
        }

        // Ottieni le dimensioni della finestra di gioco
        int width = client.getWindow().getScaledWidth();
        int height = client.getWindow().getScaledHeight();

        float zoomfactor = MathHelper.clamp(
                (SquintYourEyesClient.zoomLevel - SquintConfig.minZoom)
                        / (SquintConfig.maxZoom - SquintConfig.minZoom),
                0.0f, 1.0f
        );

        // Imposta l'opacità massima della vignetta in base al fattore di zoom e al moltiplicatore di intensità
        float maxAlpha = Math.min(1.0f, (0.6f + 0.4f * zoomfactor) * SquintConfig.intensityMultiplier);
        int alphaVignette = (int) (maxAlpha * zoomProgress * 255);

        // Calcola l'altezza della banda della vignetta in base all'altezza della finestra e al moltiplicatore di intensità
        int bandHeight = (int) ((height / 2.3) * SquintConfig.intensityMultiplier);
        int colorTop = (alphaVignette << 24);
        int colorTransparent = 0x00000000;

        context.fillGradient(0, 0, width, bandHeight, colorTop, colorTransparent);
        context.fillGradient(0, height - bandHeight, width, height, colorTransparent, colorTop);
    }
}