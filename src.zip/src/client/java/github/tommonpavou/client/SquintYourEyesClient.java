package github.tommonpavou.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SquintYourEyesClient implements ClientModInitializer {
	public static final String MOD_ID = "squint-your-eyes";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	public static KeyBinding squintKey;

	public static boolean isSquinting = false;
	public static float zoomProgress = 0.0f;
	public static float prevZoomProgress = 0.0f;

	public static float zoomLevel = 1.2f;
	public static float prevZoomLevel = 1.2f;
	public static float targetZoomLevel = 1.2f;

	// Variabile per ricordare l'ultimo livello di zoom attivo
	public static float lastActiveZoomLevel = 1.2f;

	@Override
	public void onInitializeClient() {
		// Carica o genera il file di configurazione nella cartella config
		SquintConfig.loadConfig();

		squintKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"Zoom",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_C,
				"Squint Your Eyes"
		));

		SquintHudRenderer.register();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			boolean firstPerson = client.options.getPerspective() == Perspective.FIRST_PERSON;
			boolean wasSquinting = isSquinting;
			isSquinting = squintKey.isPressed() && firstPerson;

			// Se si preme il tasto in questo esatto tick, decidi quale zoom impostare come target iniziale
			if (isSquinting && !wasSquinting) {
				float defaultZoom = 1.2f;
				targetZoomLevel = SquintConfig.rememberLastZoom ? lastActiveZoomLevel : defaultZoom;
				// Assicura che il target rientri nei limiti attuali configurati
				targetZoomLevel = MathHelper.clamp(targetZoomLevel, SquintConfig.minZoom, SquintConfig.maxZoom);
			}

			prevZoomProgress = zoomProgress;
			prevZoomLevel = zoomLevel;

			float target = isSquinting ? 1.0f : 0.0f;
			zoomProgress += (target - zoomProgress) * 0.3f;

			if (isSquinting) {
				// Memorizza continuamente l'ultimo livello mentre lo zoom è attivo
				lastActiveZoomLevel = targetZoomLevel;
			}

			if (zoomProgress < 0.001f) {
				zoomProgress = 0.0f;
				prevZoomProgress = 0.0f;
				targetZoomLevel = 1.2f;
				zoomLevel = 1.2f;
				prevZoomLevel = 1.2f;
			}

			float diff = targetZoomLevel - zoomLevel;
			if (Math.abs(diff) < 0.001f) {
				zoomLevel = targetZoomLevel;
			} else {
				zoomLevel += diff * 0.25f;
			}
		});

		LOGGER.info("Squint Your Eyes has been loaded!");
	}

	public static boolean tryAdjustZoom(double verticalScroll) {
		MinecraftClient client = MinecraftClient.getInstance();
		boolean firstPerson = client.options.getPerspective() == Perspective.FIRST_PERSON;

		if (!squintKey.isPressed() || !firstPerson) {
			return false;
		}

		// Utilizza i valori configurati dinamicamente
		targetZoomLevel = MathHelper.clamp(targetZoomLevel + (float) verticalScroll * SquintConfig.zoomStep, SquintConfig.minZoom, SquintConfig.maxZoom);
		return true;
	}

	public static Identifier id(String path) {
		return new Identifier(MOD_ID, path);
	}
}